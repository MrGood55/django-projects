from django.db import models
from django.contrib.auth.models import User

# Create your models here.
class Post(models.Model):
    title = models.CharField(max_length=255) #короткое текстовое поле длиной 255 символов
    content = models.TextField() # длинное текстовое поле без ограничений
    slug = models.SlugField(unique=True)# поле состоящее из символов и чисел. Нужно для генерации ссылок
    date_created = models.DateField(auto_now_add=True)# поле даты
    updated_at = models.DateTimeField(auto_now=True)# поле даты и времени
    author = models.ForeignKey(User, on_delete=models.CASCADE)
    likes = models.IntegerField(default=0)
    dislikes = models.IntegerField(default=0)
    dislikes_counter_allowed = models.BooleanField(default=True)
    is_allowed = models.BooleanField(default=True)  # Добавленное поле
    image = models.ImageField (verbose_name='Аватарка Поста', upload_to='post',  null=True, blank=True)
    
    # auto_now=True - снимок и автоматическое сохранение времени при любом изменении записи в таблице
    # auto_now_add=True - снимок и автоматическое сохранение времени при создании записи  в таблице
    # uniqe=True - определяет уникальность данных в столбце определенной записи
    def __str__(self):
        return self.title
    
    def slice(self):
        return ' '.join(self.content.split(' ')[:3]) + '...'
    

class Photo(models.Model):
    image = models.ImageField(default="image.jpg", blank=True)
    post = models.ForeignKey('app.Post', null=True, on_delete=models.CASCADE)

    
class PostView(models.Model):
    post = models.ForeignKey(Post, on_delete=models.CASCADE)
    ip_address = models.GenericIPAddressField()
    created_at = models.DateTimeField(auto_now_add=True)

    class Meta:
        unique_together = ['post', 'ip_address']  # Чтобы избежать повторного подсчета просмотров от одного IP
    
    def __str__(self):
        return f'Просмотр поста "{self.post.title}" от {self.created_at}'
    
    # ----------------------------------------18.03.24
    