from django.urls import path
from.import views
# -------------
from django.urls import path
# from users import views

urlpatterns = [
    path('', views.index, name='index'),
    path('<app_slug>/', views.app_full, name='app_full'),
    path('post_create', views.post_create, name='post_create'),
    # path('post/<str:slug>', views.post_detail, name='post')
    path('personal_cabinet', views.personal_cabinet, name='personal_cabinet'),

    path('like/<str:post_id>/', views.like_post, name='like_post'),
    path('dizlike/<str:post_id>/', views.dizlike_post, name='dizlike_post'),

    path('delete_post/<str:post_id>/', views.delete_post, name='delete_post'),
    
]
    
    
