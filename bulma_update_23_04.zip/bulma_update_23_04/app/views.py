from django.shortcuts import render, redirect
from django.http import HttpResponse

from django.shortcuts import redirect
from django.shortcuts import get_object_or_404
from django.http import HttpResponseNotFound
from .models import *
from comments.models import *
from .forms import *
from comments.models import *
from django.views.decorators.csrf import csrf_exempt
from datetime import datetime
#Добавил  ДЗ 66 задание
from django.contrib.auth.decorators import login_required
from django.db.models import Count
# ---------------------------------------------
def index(request):
    # return HttpResponse('<h1> Привет, Мир!<h1>')
    posts = Post.objects.all()

    # update 23_04
    sort_posts = request.GET.get('sort_posts')
    if sort_posts == 'from_top':
        posts = posts.annotate(view_count=Count('postview')).order_by('-view_count')
    elif sort_posts == 'from_bottom':
        posts = posts.annotate(view_count=Count('postview')).order_by('view_count')

    

    context = {
        "posts": posts,
        "title": "Главная страница",
        "students": ["Вася", "Петя", "Даша", "Маша"],
    }
    return render(request, "index.html", context)


def page404(request, slug):
    return render





def app_full(request, app_slug):
    
    app_full = get_object_or_404(Post, slug=app_slug)
    # posts = Post.objects.annotate(num_views=Count('postview')).order_by('-num_views')
    # post = get_object_or_404(Post, slug=slug)
    
    # Создание записи о просмотре
    if request.user.is_authenticated:  # Если пользователь аутентифицирован
        if not PostView.objects.filter(post=app_full, ip_address=request.user.ip_address).exists():  # Проверяем, был ли уже просмотр этого поста этим пользователем
            PostView.objects.create(post=app_full, ip_address=request.user.ip_address)
    else:  # Если пользователь не аутентифицирован
        user_ip = request.META.get('REMOTE_ADDR')  # Получаем IP-адрес пользователя
        if not PostView.objects.filter(post=app_full, ip_address=user_ip).exists():  # Проверяем, был ли уже просмотр этого поста с этого IP-адреса
            PostView.objects.create(post=app_full, ip_address=user_ip)
            
    if request.method=='POST' and 'comment_add' in request.POST:
        
        commentform = ComentForm(request.POST)

        if commentform.is_valid():

            commentform_user = commentform.cleaned_data['user']
            commentform_post_id = commentform.cleaned_data['post_id']
            commentform_body = commentform.cleaned_data['body']
            
            
            user_post = User.objects.get(id = commentform_user)
            
            
            post_post = Post.objects.get(id = commentform_post_id)
            
            
            commentform = Comments(
                user = user_post,
                post_id = post_post,
                body = commentform_body,
                date = timezone.now(),
                like = 0,
                dizlike = 0,
            )
            commentform.save()
                    

    elif request.method == 'POST' and 'comment_add_to_comment'  in request.POST:
                

        commentform = ComentForm(request.POST)
        
        if commentform.is_valid():
            
            
            commentform_id_comment = commentform.cleaned_data['name_to_comment']
            commentform_user = commentform.cleaned_data['user']
            commentform_post_id = commentform.cleaned_data['post_id']
            commentform_body = commentform.cleaned_data['body']
            
            user_post = User.objects.get(id = commentform_user)
            
            
            post_post = Post.objects.get(id = commentform_post_id)
            
            
            commentform = Comments(
                user = user_post,
                post_id = post_post,
                body = f"""
                <em style="color: grey; font-size: 11px;">{Comments.objects.get(id = commentform_id_comment).body.split('</em>')[-1].replace('<br>','').replace('Ответ:','')}</em>
                <br><br>
                Ответ:
                <br>
                """ + commentform_body,
                date = timezone.now(),
                like = 0,
                dizlike = 0,
            )
            commentform.save()
                    
   
        
    elif request.method == 'POST' and 'config_comment'  in request.POST:
        comment_id = request.POST.get('name_to_comment', None)
        comment = get_object_or_404(Comments, id=comment_id)
        commentform = ComentForm(request.POST)

        if commentform.is_valid():
            if 'Ответ' in comment.body:
                print('Ответ есть внутри')
                new_body = '<br>'.join(comment.body.split('<br>')[:-1])+commentform.cleaned_data['body']
                print(f"{new_body}")
            else:
                print('Ответа нет внутри')
                new_body = commentform.cleaned_data['body']
                print(f"{new_body}")   
            
            commentform_user_id = commentform.cleaned_data['user']
            commentform_post_id = commentform.cleaned_data['post_id']

            # Обновление полей комментария
            comment.body = new_body
            comment.user_id = commentform_user_id
            comment.post_id_id = commentform_post_id
            comment.save()
            

    elif request.method == 'POST' and 'config_post'  in request.POST:  

        post_id = request.POST.get('post_id', None)
        new_title = request.POST.get('title', None)
        new_content = request.POST.get('content', None)

        check_is_allowed = request.POST.get('is_allowed', False)
        print(f'/n/n {check_is_allowed}/n/n')

        
        post = get_object_or_404(Post, id=post_id)
        post.title = new_title
        post.content = new_content
        post.is_allowed= check_is_allowed 
        
        # print('/n/n',datetime.now().strftime('YYYY-MM-DD'),'/n/n') 
        post.save()
        app_full = get_object_or_404(Post, slug=app_slug)
        commentform = ComentForm()
        

    else:
        if request.method == 'POST' and 'delete_comment'  in request.POST: 
            comment_id = request.POST.get('name_to_comment')
            comment = get_object_or_404(Comments, pk=comment_id)
            comment.delete()
        commentform = ComentForm()

    comments = Comments.objects.filter(post_id=app_full)
    comments = comments.values()
    
# Цветовая полоса. Расчет процентов 8 апреля 
    sum_lik_dislike = (app_full.likes+app_full.dislikes)
    
    if sum_lik_dislike != 0:
        post_likes_percent = int((app_full.likes/(app_full.likes+app_full.dislikes))*100)
        post_dislikes_percent = int((app_full.dislikes/(app_full.likes+app_full.dislikes))*100)
    elif sum_lik_dislike == 0:
        post_likes_percent = 50
        post_dislikes_percent = 50

    for item in comments:
        if item['dizlike']+item['like'] != 0:
            item['percent_like'] = int((item['like']/(item['dizlike']+item['like']))*100)
        elif item['dizlike']+item['like'] == 0:
            item['percent_like'] = 50
        if item['dizlike']+item['like'] != 0:
            item['percent_dizlike'] = int((item['dizlike']/(item['dizlike']+item['like']))*100)
        elif item['dizlike']+item['like'] == 0:
            item['percent_dizlike'] = 50


# Цветовая шкала процентов

    response = render(request, "post.html", {
        "app_full": app_full,
        'comments': comments,
        'commentform':commentform,
        'post_likes_percent':post_likes_percent,
        'post_dislikes_percent':post_dislikes_percent,
        
    })
    
    return response


def post_create(request):
    post_form = PostForm(request.POST)
   
   
    
    if request.method =='POST' and post_form.is_valid():
        images= request.FILES.getlist('images')
        
        
        instance = post_form.save(commit=False)
        instance.author = request.user
        instance.save()
        
        for image in images:
            Photo.objects.create(post=instance, image=image)
            
        return redirect('app:index')
    
    post_form = PostForm()    
    return render(request, "post_create.html", {"post_form": post_form})


# ----------------------------------------18.03.24
from django.shortcuts import get_object_or_404
from django.http import JsonResponse


@csrf_exempt
def like_post(request, post_id):
    post = get_object_or_404(Post, id=post_id)
    post.likes += 1
    post.save()
    return JsonResponse({'likes': post.likes})


@csrf_exempt
def dizlike_post(request, post_id):
    post = get_object_or_404(Post, id=post_id)
    post.dislikes += 1
    post.save()
    return JsonResponse({'dislikes': post.dislikes})





#Добавил 2 задание

@login_required
def personal_cabinet(request):

    """ 
    Создать личный кабинет, где будет username пользователя я также таблица с опубликованными постами. Таблица состоит из:
    -  id поста
    -  имени поста
    -  даты создания
    -  кол-во комментариев под постом
    """

    user = request.user
    

    user_posts = Post.objects.filter(author=user)
    post_comments_arr = []
    for post in user_posts:
        dict_to_post_arr = {}
        comments_count = Comments.objects.filter(post_id=post) 
        dict_to_post_arr['id'] = post.id
        dict_to_post_arr['title'] = post.title
        dict_to_post_arr['date_created'] = post.date_created 
        dict_to_post_arr['count'] = comments_count.count()
        post_comments_arr.append(dict_to_post_arr)
    # Передаем данные в шаблон
    return render(request, 'personal_cabinet.html', {'user': user,  'post_comments_arr': post_comments_arr})


# ==== УДАЛЕНИЕ


@login_required
def delete_post(request, post_id):
    # print(f' {post_id} is deleted')
    post = get_object_or_404(Post, pk=post_id)
    post.delete()
    return redirect('app:index')


