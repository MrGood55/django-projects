from django.shortcuts import render, redirect
from django.http import HttpResponse

from django.shortcuts import redirect
from django.shortcuts import get_object_or_404
from django.http import HttpResponseNotFound

from .forms import *
from django.contrib.auth import login, logout


# def sign_in_view(request):
#     context = {
#         'title': "Зарегестрироваться"               
#     }
#     return render(request, 'users/users_sign_in.html', context)

# def sign_up_view(request):
#     context = {
#         'title': "Войти"    
#     }  
#     return render(request, 'users/users_sign_up.html', context)

# def sign_out_view(request):
#     context = {
#         'title': "Выйти"    
#     }  
    
#     return render(request, 'users/users_sign_out.html', context)


def sign_up(request):
    form = SignUpForm(request.POST)
    if form.is_valid() and request.method== 'POST':
        
        
        form.save()
        return redirect('app:index')
    return render(request, 'users/sign_up.html', {'form': form})


def sign_in(request):
    form = SignInpForm(data=request.POST)
    
    if form.is_valid():
        user = form.get_user()
        login(request, user)
        
        if 'next' in request.GET:
            return redirect(request.GET.get('next'))
        
        
        return redirect('app:index')
    return render(request, 'users/sign_in.html', {'form': form})

def sign_out(request):
    # sign_out_flag = request.method == "POST"
    # if sign_out_flag:
    #     print(request.path)
        logout(request)
        return redirect('users:sign-in',)
