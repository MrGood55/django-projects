from django.shortcuts import render
from django.http import HttpResponse
from comments.models import *

from django.contrib.auth import login, logout
from django.core.paginator import Paginator, EmptyPage, PageNotAnInteger
from comments.models import Comments

def about(request):
    context = {
               'title': "О компании"
               }
    return render(request, 'about.html', context)

def contacts (request):
    context = {
        'title': "Контакты"               
    }
    return render(request, 'contacts.html', context)

def post_detail(request, slug):
    # post = Post.objects.get(slug=slug)
    # comments = Comments.objects.all()
    # print(post)
    # return render(request, 'post.html', {
    #      'comments': comments,
    # })
    return '' 



def usersall(request):
    context = {
        'title': "Пользователи"               
    }
    return render(request, 'usersall.html', context)




# ---------------------------------------------18.03.24

# from django.shortcuts import get_object_or_404
# from django.http import JsonResponse

# def like_post(request, post_id):
#     post = get_object_or_404(Post, id=post_id)
#     post.likes += 1
#     post.save()
#     return JsonResponse({'likes': post.likes})

# def dislike_post(request, post_id):
#     post = get_object_or_404(Post, id=post_id)
#     post.dislikes += 1
#     post.save()
#     return JsonResponse({'dislikes': post.dislikes})

# ------------------------------------------------
def page404 (request):
    context = {
        'title': "404"               
    }
    return render(request, '404.html', context)

def treejs (request):
    context = {
        'title': "treejs"               
    }
    return render(request, 'treejs.html', context)






def handler404(request, exception):
    return render(request, '404.html', status=404)


def handler400(request, *args, **argv):

	template = loader.get_template("400.html")
	response = HttpResponse(template.render({}, request))
	response.status_code = 400
	return response


def handler403(request, *args, **argv):

	template = loader.get_template("403.html")
	response = HttpResponse(template.render({}, request))
	response.status_code = 403
	return response


def handler500(request, *args, **argv):
	
	template = loader.get_template("500.html")
	response = HttpResponse(template.render({}, request))
	response.status_code = 500
	return response


def one_page(request):
    return render(request, 'one_page.html')




# def comments(request):
#     comment_list = Comments.objects.all().order_by('-date')
#     paginator = Paginator(comment_list, 10) 

#     page = request.GET.get('page')
#     try:
#         comments = paginator.page(page)
#     except PageNotAnInteger:
#         comments = paginator.page(1)
#     except EmptyPage:
#         comments = paginator.page(paginator.num_pages)
#     print(len([comment.user for comment in comments]))
#     return render(request, 'comments.html', {'comments': comments,'title': "Комментарии"})


# ---------------------update 23_04

def comments(request):
    comment_list = Comments.objects.all()

    # Фильтрация по количеству лайков
    sort_by_likes = request.GET.get('sort_by_likes')
    if sort_by_likes == 'asc':
        comment_list = comment_list.order_by('like')
    elif sort_by_likes == 'desc':
        comment_list = comment_list.order_by('-like')


    # Фильтрация по порядку добавления (новые или старые)
    sort_by_date = request.GET.get('sort_by_date')
    if sort_by_date == 'old':
        comment_list = comment_list.order_by('date')
    elif sort_by_date == 'new':
        comment_list = comment_list.order_by('-date')

    paginator = Paginator(comment_list, 10)  

    page = request.GET.get('page')
    try:
        comments = paginator.page(page)
    except PageNotAnInteger:
        comments = paginator.page(1)
    except EmptyPage:
        comments = paginator.page(paginator.num_pages)

    return render(request, 'comments.html', {'comments': comments, 'title': "Комментарии"})
