from django.db import models

from django.contrib.auth.models import User
from django.utils import timezone

from app.models import *



class Comments(models.Model):
    user = models.ForeignKey(User, on_delete=models.CASCADE)
    post_id = models.ForeignKey(Post, on_delete=models.CASCADE, default="", null=True, blank=True)
    body = models.TextField(null=True, blank=True)
    date = models.DateTimeField(default=timezone.now)
    like = models.IntegerField(default="0", null=True, blank=True)
    dizlike = models.IntegerField(default="0", null=True, blank=True)
    avatar = models.ImageField (u'Аватарка', upload_to='avatar',  null=True, blank=True, max_length=255)
    
    def __str__(self):
        return f'{self.user.username} - {self.id}'
